package LeviathansMark.States;

import LeviathansMark.Graphics.ImageLoader;
import LeviathansMark.RefLinks;

import java.awt.*;
import java.awt.image.BufferedImage;

/*! \class public class MenuState extends State
    \brief Implementeaza notiunea de menu pentru joc.
 */
public class MenuState extends State
{

    public BufferedImage meniu= ImageLoader.LoadImage("/1.jpg");
    public Rectangle playButton=new Rectangle(350,250,100,50);
    public Rectangle quitButton=new Rectangle(350,350,100,50);

    public MenuState(RefLinks refLink)
    {
        super(refLink);
    }

    @Override
    public void Update()
    {

    }

    @Override
    public void Draw(Graphics g)
    {
        Graphics2D g2d=(Graphics2D) g;
        Font fnt0=new Font("arial",Font.BOLD,50);
        g.setFont(fnt0);
        g.setColor(Color.black);
        g.drawImage(this.meniu,0,0,null);
        g.drawString("Leviathan's Mark",180,100);
        Font fnt1=new Font("arial",1,30);
        g.setFont(fnt1);
        g.drawString("Play",playButton.x+19,playButton.y+30);
        g2d.draw(this.playButton);
        g.drawString("Quit",quitButton.x+19,quitButton.y+30);
        g2d.draw(this.quitButton);

    }


}

