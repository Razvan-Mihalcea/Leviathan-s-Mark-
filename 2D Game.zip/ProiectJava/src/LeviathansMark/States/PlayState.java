package LeviathansMark.States;

import LeviathansMark.Items.Enemy;
import LeviathansMark.Items.Hero;
import LeviathansMark.RefLinks;
import LeviathansMark.Maps.Map;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Iterator;

/*! \class public class PlayState extends State
    \brief Implementeaza/controleaza jocul.
 */
public class PlayState extends State {
    private Hero hero;  /*!< Referinta catre obiectul animat erou (controlat de utilizator).*/
    private Map map;    /*!< Referinta catre harta curenta.*/
    private ArrayList<Enemy> enemies;
    private int actualenemy;
    private int lvlindex;

    /*! \fn public PlayState(RefLinks refLink)
        \brief Constructorul de initializare al clasei

        \param refLink O referinta catre un obiect "shortcut", obiect ce contine o serie de referinte utile in program.
     */
    public PlayState(RefLinks refLink) {
        ///Apel al constructorului clasei de baza
        super(refLink);
        ///Construieste harta jocului
        map = new Map(refLink);
        ///Referinta catre harta construita este setata si in obiectul shortcut pentru a fi accesibila si in alte clase ale programului.
        refLink.SetMap(map);
        ///Construieste eroul
        hero = new Hero(refLink, 60, 60);
        hero.SetLife(50);
        enemies = new ArrayList<>();
        enemies.add(new Enemy(refLink, 700, 740, 32, 32));
        enemies.add(new Enemy(refLink, 700, 130, 32, 32));
        enemies.add(new Enemy(refLink, 120, 490, 32, 32));

    }

    /*! \fn public void Update()
        \brief Actualizeaza starea curenta a jocului.
     */
    @Override
    public void Update() {
        actualenemy = -1;
        lvlindex=1;
        map.Update();
        hero.Update();

        //Design pattern <333 Iterator

        Iterator<Enemy> itr=enemies.iterator();
        while(itr.hasNext())
        {
            itr.next().Update();
        }
        /*for (Enemy enemy : enemies)
            enemy.Update();*/
        if (map.GetTile((int) hero.GetX() / 32, (int) hero.GetY() / 32).IsSolid() ||
                map.GetTile((int) (hero.GetX() + hero.getBounds().width) / 32, (int) hero.GetY() / 32).IsSolid() ||
                map.GetTile((int) (hero.GetX() + hero.getBounds().width) / 32, (int) (hero.GetY() + hero.getBounds().height) / 32).IsSolid() ||
                map.GetTile((int) hero.GetX() / 32, (int) (hero.GetY() + hero.getBounds().height) / 32).IsSolid()) {
            System.out.println("Collided");
            hero.SetXMove(-hero.GetXMove());
            hero.SetYMove(-hero.GetYMove());
            hero.Move();
        }

        for (Enemy enemy : enemies) {
            if (!(hero.GetX() > enemy.GetX() + enemy.getBounds().width ||
                    hero.GetX() < enemy.GetX() - hero.getBounds().getWidth() ||
                    hero.GetY() > enemy.GetY() + enemy.getBounds().height ||
                    hero.GetY() < enemy.GetY() - hero.getBounds().getWidth())) {
                System.out.println("Collided");
                hero.SetXMove(-hero.GetXMove());
                hero.SetYMove(-hero.GetYMove());
                hero.Move();
            }
        }
        for (Enemy zombie : enemies) {
            if (zombie.Exist(hero.GetX(), hero.GetY()) ||
                    zombie.Exist(hero.GetX() + hero.GetWidth(), hero.GetY()) ||
                    zombie.Exist(hero.GetX(), hero.GetY() + hero.GetHeight()) ||
                    zombie.Exist(hero.GetX(), hero.GetY() + hero.GetHeight()) ||
                    zombie.Exist(hero.GetX() + hero.GetWidth(), hero.GetY() + hero.GetHeight())) {
                hero.setXMove(-hero.GetXMove());
                hero.setYMove(-hero.GetYMove());
                hero.Move();
                actualenemy = enemies.indexOf(zombie);
            }
        }
        System.out.println((int) hero.GetX() / 16 + " " + (int) hero.GetY() / 16);
        if (actualenemy >= 0) {
            if (hero.GetAttack()) {
                enemies.get(actualenemy).GetDamage(2);
            } else {
                hero.GetDamage(1);
            }
            if (enemies.get(actualenemy).GetLife() <= 0) {
                enemies.remove(actualenemy);
                hero.Punctajinc(1);
            }
        }
        if(hero.GetPunctaj()==3 && enemies.isEmpty())
        {
            map.LoadWorld(2);
            hero.SetX(80);
            hero.SetY(100);
            enemies.add(new Enemy(refLink, 730, 640, 32, 32));
            enemies.add(new Enemy(refLink, 450, 200, 32, 32));
            enemies.add(new Enemy(refLink, 140, 450, 32, 32));
            enemies.add(new Enemy(refLink, 630, 550, 32, 32));
            enemies.add(new Enemy(refLink, 540, 350, 32, 32));

        }
        if(enemies.isEmpty() && hero.GetPunctaj()==7)
        {
            System.out.println("Ai castigat");
        }
        if(hero.GetLife()<=0)
        {
            System.out.println("Ai pierdut");
        }

    }


    /*! \fn public void Draw(Graphics g)
        \brief Deseneaza (randeaza) pe ecran starea curenta a jocului.

        \param g Contextul grafic in care trebuie sa deseneze starea jocului pe ecran.
     */
    @Override
    public void Draw(Graphics g) {
        map.Draw(g);
        hero.Draw(g);
        for (Enemy enemy : enemies) // iterator - Design pattern
            enemy.Draw(g);
        g.setFont(new Font("Arial", 1, 15));
        g.setColor(Color.white);
        g.drawRect(0, 0, 80, 30);
        g.drawString("Punctaj: " + this.hero.GetPunctaj(), 5, 20);
        g.drawRect(719, 0, 80, 30);
        g.drawString("Viata: " + this.hero.GetLife(), 725, 20);
    }
}
