package LeviathansMark.Maps;

import LeviathansMark.RefLinks;
import LeviathansMark.Tiles.Tile;

import java.awt.*;

/*! \class public class Map
    \brief Implementeaza notiunea de harta a jocului.
 */
public class Map {
    private RefLinks refLink;   /*!< O referinte catre un obiect "shortcut", obiect ce contine o serie de referinte utile in program.*/
    private int width;          /*!< Latimea hartii in numar de dale.*/
    private int height;         /*!< Inaltimea hartii in numar de dale.*/
    private int[][] tiles;/*!< Referinta catre o matrice cu codurile dalelor ce vor construi harta.*/

    /*! \fn public Map(RefLinks refLink)
        \brief Constructorul de initializare al clasei.

        \param refLink O referinte catre un obiect "shortcut", obiect ce contine o serie de referinte utile in program.
     */
    public Map(RefLinks refLink) {
        /// Retine referinta "shortcut".
        this.refLink = refLink;
        ///incarca harta de start. Functia poate primi ca argument id-ul hartii ce poate fi incarcat.
        LoadWorld(1);
    }

    /*! \fn public  void Update()
        \brief Actualizarea hartii in functie de evenimente (un copac a fost taiat)
     */
    public void Update() {

    }

    /*! \fn public void Draw(Graphics g)
        \brief Functia de desenare a hartii.

        \param g Contextl grafi in care se realizeaza desenarea.
     */
    public void Draw(Graphics g) {
        ///Se parcurge matricea de dale (codurile aferente) si se deseneaza harta respectiva
        for (int y = 0; y < refLink.GetGame().GetHeight() / 32; y++) {
            for (int x = 0; x < refLink.GetGame().GetWidth() / 32; x++) {
                GetTile(x, y).Draw(g, (int) x * 32, (int) y * 32);
            }
        }
    }

    /*! \fn public Tile GetTile(int x, int y)
        \brief Intoarce o referinta catre dala aferenta codului din matrice de dale.

        In situatia in care dala nu este gasita datorita unei erori ce tine de cod dala, coordonate gresite etc se
        intoarce o dala predefinita
     */
    public Tile GetTile(int x, int y) {
        if (x < 0 || y < 0 || x >= width || y >= height) {
            return Tile.margine;
        }
        Tile t = Tile.tiles[tiles[x][y]];
        if (t == null) {
            return Tile.zid;
        }
        return t;
    }

    /*! \fn private void LoadWorld()
        \brief Functie de incarcare a hartii jocului.
        Aici se poate genera sau incarca din fisier harta. Momentan este incarcata static.
     */
    public void LoadWorld(int index) {
        //atentie latimea si inaltimea trebuiesc corelate cu dimensiunile ferestrei sau
        //se poate implementa notiunea de camera/cadru de vizualizare al hartii
        ///Se stabileste latimea hartii in numar de dale.
        width = 25;
        ///Se stabileste inaltimea hartii in numar de dale
        height = 25;
        ///Se construieste matricea de coduri de dale
        tiles = new int[width][height];
        //Se incarca matricea cu coduri
        switch (index) {
            case 1: {
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        tiles[x][y] = Level1Map(y, x);
                    }
                }
                break;
            }
            case 2: {
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        tiles[x][y] = Level2Map(y, x);
                    }
                }
                break;
            }
            default: {
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        tiles[x][y] = Level1Map(y, x);
                    }
                }
                break;
            }
        }
    }

    /*! \fn private int MiddleEastMap(int x ,int y)
        \brief O harta incarcata static.

        \param x linia pe care se afla codul dalei de interes.
        \param y coloana pe care se afla codul dalei de interes.
     */
    private int Level1Map(int x, int y) {
        ///Definire statica a matricei de coduri de dale.
        final int[][] map = {
                {0, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 2, 2, 2},
                {0, 7, 7, 7, 5, 5, 5, 5, 5, 5, 5, 1, 3, 3, 3, 3, 3, 3, 4, 15, 7, 7, 7, 15, 8},
                {0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 2, 2, 2, 4, 4, 4, 4, 7, 7, 7, 7, 7, 8},
                {0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8},
                {0, 7, 5, 7, 7, 7, 7, 7, 7, 7, 7, 7, 3, 3, 3, 3, 3, 3, 7, 7, 5, 7, 7, 7, 8},
                {0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 5, 7, 7, 7, 8},
                {0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 5, 1, 4, 4, 2, 4, 4, 4, 4, 7, 7, 7, 7, 7, 8},
                {0, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 1, 3, 3, 3, 3, 3, 3, 4, 7, 7, 5, 5, 7, 8},
                {0, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 3, 4, 7, 7, 7, 7, 7, 8},
                {3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 7, 7, 7, 7, 7, 8},
                {3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 7, 7, 5, 7, 7, 8},
                {3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 7, 7, 5, 7, 7, 8},
                {3, 0, 4, 4, 4, 4, 4, 4, 2, 4, 4, 3, 3, 3, 3, 3, 3, 3, 4, 7, 7, 7, 7, 7, 8},
                {3, 0, 7, 7, 7, 7, 7, 7, 7, 7, 4, 3, 3, 3, 3, 3, 3, 3, 4, 7, 5, 5, 7, 7, 8},
                {3, 0, 7, 7, 5, 7, 7, 7, 7, 7, 4, 4, 4, 4, 2, 4, 4, 4, 4, 7, 5, 7, 7, 7, 8},
                {3, 0, 7, 7, 5, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 5, 7, 7, 7, 7, 7, 7, 7, 8},
                {3, 0, 7, 7, 7, 7, 5, 7, 7, 7, 5, 7, 7, 5, 7, 7, 7, 5, 7, 5, 7, 7, 7, 7, 8},
                {3, 0, 7, 5, 5, 7, 7, 7, 5, 7, 5, 5, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 6, 6, 8},
                {3, 0, 7, 7, 5, 7, 7, 5, 6, 6, 4, 4, 4, 2, 4, 4, 4, 4, 4, 4, 4, 2, 4, 4, 8},
                {3, 0, 7, 7, 7, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3},
                {3, 0, 7, 5, 7, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3},
                {3, 0, 7, 5, 7, 4, 2, 4, 4, 2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 2, 2, 4, 4, 8},
                {3, 0, 7, 5, 5, 7, 5, 7, 7, 7, 7, 7, 7, 7, 7, 5, 7, 5, 5, 7, 7, 7, 7, 7, 8},
                {3, 0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 5, 7, 5, 7, 7, 7, 7, 5, 7, 5, 5, 5, 7, 8},
                {3, 0, 4, 2, 4, 4, 2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 2, 2, 4, 4, 4, 4, 8}};
        return map[x][y];
    }
    private int Level2Map(int x,int y)
    {
        final int[][] map= {
                {30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30},
                {30, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 27, 23, 23, 23, 27, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 24, 23, 23, 22, 23, 23, 23, 23, 22, 23, 23, 22, 23, 23, 24, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 24, 22, 23, 23, 22, 22, 23, 23, 22, 23, 22, 23, 22, 23, 24, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 24, 22, 23, 22, 23, 22, 23, 23, 23, 22, 22, 23, 22, 23, 24, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 24, 22, 23, 23,23, 23, 23, 23, 23, 23, 22, 22, 23, 23, 24, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 23, 19, 19, 19, 19, 19, 19, 23, 23, 19, 19, 19, 19, 19, 19, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 30},
                {30, 23, 23, 23, 27, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 27, 23, 23, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 23, 27, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 27, 27, 23, 23, 23, 23, 23, 23, 23, 30},
                {30, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 30},
                {30,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,30},
                {30,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,30},
                {30,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,30},
                {30,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,30},
                {30,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,30},
                {30,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,30},
                {30,23,23,33,34,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,30},
                {30,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,30},
                {30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30}};
        return map[x][y];
    }
}