package LeviathansMark.Input;

import LeviathansMark.RefLinks;
import LeviathansMark.States.State;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class MouseHandler implements MouseListener, MouseMotionListener{

        private boolean leftpressed,rightpressed, rotatepressed;
        private int mousex,mousey;

        public MouseHandler(){}


        @Override
        public void mouseClicked(MouseEvent e) {

        }

        @Override
        public void mousePressed(MouseEvent e) {
            int mx = e.getX();
            int my = e.getY();
            //Play
            if(State.GetState()== RefLinks.GetGame().getMenuState()) {
                if (mx >= 800 / 2 - 50 && mx <= 800 / 2 + 50) {
                    if (my >= 250 && my <= 300) {
                        State.SetState(RefLinks.GetGame().getPlayState());

                    }
                }

                //quit
                if (mx >= 800 / 2 - 50 && mx <= 800 / 2 + 50) {
                    if (my >= 350 && my <= 400) {
                        System.exit(1);
                    }
                }
            }
            if(e.getButton()==MouseEvent.BUTTON1){
                leftpressed=true;
            }
            else if(e.getButton()==MouseEvent.BUTTON3){
                rightpressed=true;
            }else if(e.getButton()==MouseEvent.BUTTON2){
                rotatepressed=true;
            }
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            if(e.getButton()==MouseEvent.BUTTON1){
                leftpressed=false;
            }
            else if(e.getButton()==MouseEvent.BUTTON3){
                rightpressed=false;
            }else if(e.getButton()==MouseEvent.BUTTON2){
                rotatepressed=false;
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }

        @Override
        public void mouseDragged(MouseEvent e) {

        }

        @Override
        public void mouseMoved(MouseEvent e) {
            mousex=e.getX();
            mousey=e.getY();
        }
}
