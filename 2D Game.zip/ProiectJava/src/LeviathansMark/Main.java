package LeviathansMark;

public class Main
{
    public static void main(String[] args)
    {
        try {
            Game LeviathansMark = new Game("Leviathan's Mark", 25*32, 25*32);
            LeviathansMark.StartGame();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
