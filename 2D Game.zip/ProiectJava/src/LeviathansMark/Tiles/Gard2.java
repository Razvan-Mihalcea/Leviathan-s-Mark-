package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class Gard2 extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Gard2() {
        super(Assets.gard2, Assets.index("gard2"));
    }
}