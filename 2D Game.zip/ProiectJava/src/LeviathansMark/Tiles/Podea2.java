package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

/*! \class public class SoilTile extends Tile
    \brief Abstractizeaza notiunea de dala de tip sol/pamant.
 */
public class Podea2 extends Tile
{
    /*! \fn public SoilTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Podea2()
    {
        super(Assets.podea2, Assets.index("podea2"));
    }

}
