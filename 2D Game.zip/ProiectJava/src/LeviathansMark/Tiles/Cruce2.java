package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class Cruce2 extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Cruce2() {
        super(Assets.cruce2, Assets.index("cruce2"));
    }
}
