package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class Lumanare extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Lumanare() {
        super(Assets.lumanare, Assets.index("lumanare"));
    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }
}
