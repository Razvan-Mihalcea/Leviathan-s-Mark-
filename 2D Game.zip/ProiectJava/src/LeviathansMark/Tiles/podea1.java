package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

/*! \class public class SoilTile extends Tile
    \brief Abstractizeaza notiunea de dala de tip sol/pamant.
 */
public class podea1 extends Tile
{
    /*! \fn public SoilTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public podea1()
    {
        super(Assets.podea1, Assets.index("podea1"));
    }

}