package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

/*! \class public class MountainTile extends Tile
    \brief Abstractizeaza notiunea de dala de tip munte sau piatra.
 */
public class Zid extends Tile {

    /*! \fn public MountainTile(int id)
       \brief Constructorul de initializare al clasei

       \param id Id-ul dalei util in desenarea hartii.
    */
    public Zid()
    {
            /// Apel al constructorului clasei de baza
        super(Assets.zid, Assets.index("zid"));
    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }

    /*! \fn public boolean IsSolid()
        \brief Suprascrie metoda IsSolid() din clasa de baza in sensul ca va fi luat in calcul in caz de coliziune.
     */
   /* @Override
    public boolean IsSolid()
    {
        return true;
    }*/
}
