package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class Marginezid extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Marginezid() {
        super(Assets.marginezid, Assets.index("marginezid"));
    }
}