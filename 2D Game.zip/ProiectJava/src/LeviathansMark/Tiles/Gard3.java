package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class Gard3 extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Gard3() {
        super(Assets.gard3, Assets.index("gard3"));
    }
}
