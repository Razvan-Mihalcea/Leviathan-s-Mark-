package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class Coffin2 extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Coffin2() {
        super(Assets.coffin2, Assets.index("coffin2"));
    }
}
