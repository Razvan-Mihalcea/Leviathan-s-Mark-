package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

    public class PodeaIarba extends Tile
    {
        /*! \fn public SoilTile(int id)
            \brief Constructorul de initializare al clasei

            \param id Id-ul dalei util in desenarea hartii.
         */
        public PodeaIarba()
        {
            super(Assets.podeaiarba, Assets.index("podeaiarba"));
        }

        @Override
        public boolean IsSolid() {
            return false;
        }
    }

