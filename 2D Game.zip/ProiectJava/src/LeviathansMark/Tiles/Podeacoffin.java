package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class Podeacoffin extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Podeacoffin() {
        super(Assets.podeacoffin, Assets.index("podeacoffin"));
    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }
}
