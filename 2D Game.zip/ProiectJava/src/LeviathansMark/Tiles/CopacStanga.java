package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class CopacStanga extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public CopacStanga() {
        super(Assets.copacstanga, Assets.index("copacstanga"));

    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }
}
