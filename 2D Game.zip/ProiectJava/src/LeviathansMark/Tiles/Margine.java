package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

/*! \class public class GrassTile extends Tile
    \brief Abstractizeaza notiunea de dala de tip iarba.
 */
public class Margine extends Tile
{
    /*! \fn public GrassTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Margine()
    {
            /// Apel al constructorului clasei de baza
        super(Assets.margine, Assets.index("margine"));
    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }
}
