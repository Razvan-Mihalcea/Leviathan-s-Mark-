package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class Gard1 extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Gard1() {
        super(Assets.gard1, Assets.index("gard1"));
    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }
}
