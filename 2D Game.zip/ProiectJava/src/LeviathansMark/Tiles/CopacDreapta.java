package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class CopacDreapta extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public CopacDreapta() {
        super(Assets.copacdreapta, Assets.index("copacdreapta"));
    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }
}
