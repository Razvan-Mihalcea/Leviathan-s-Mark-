package LeviathansMark.Tiles;

import java.awt.*;
import java.awt.image.BufferedImage;

/*! \class public class Tile
    \brief Retine toate dalele intr-un vector si ofera posibilitatea regasirii dupa un id.
 */
public class Tile
{
    private static final int NO_TILES   = 40;
    public static Tile[] tiles          = new Tile[NO_TILES];       /*!< Vector de referinte de tipuri de dale.*/

        /// De remarcat ca urmatoarele dale sunt statice si publice. Acest lucru imi permite sa le am incarcate o singura data in memorie
    public static Tile blocNegru        = new BlocNegru();      /*!< Dala de tip copac*/
    public static Tile margine       = new Margine();     /*!< Dala de tip iarba*/
    public static Tile zid     = new Zid();  /*!< Dala de tip munte/piatra*/
    public static Tile zidIarba       = new ZidIarba();     /*!< Dala de tip apa*/
    public static Tile zidcrapat        = new Zidcrapat();      /*!< Dala de tip sol/pamant*/
    public static Tile podeaiarba            = new PodeaIarba();
    public static Tile podea            = new Podea();
    public static Tile cutie = new Cutie();
    public static Tile obiect = new Obiect();
    public static Tile podea1 = new podea1();
    public static Tile podea2 = new Podea2();
    public static Tile podea3 = new Podea3();
    public static Tile podea4 = new Podea4();
    public static Tile podea5 = new Podea5();
    public static Tile podea6 = new Podea6();
    public static Tile podea7 = new Podea7();
    public static Tile zidiarba2 = new ZidIarba2();
    public static Tile gard1 =new Gard1();
    public static Tile gard2=new Gard2();
    public static Tile gard3=new Gard3();
    public static Tile coffin=new Coffin();
    public static Tile coffin2=new Coffin2();
    public static Tile podealvl2=new PodeaLvl2();
    public static Tile gard4=new Gard4();
    public static Tile gard5=new Gard5();
    public static Tile podeacoffin=new Podeacoffin();
    public static Tile marginezid=new Marginezid();
    public static Tile marginezid2=new Marginezid2();
    public static Tile lumanare=new Lumanare();
    public static Tile cruce=new Cruce();
    public static Tile cruce2=new Cruce2();
    public static Tile copacstanga=new CopacStanga();
    public static Tile copacdreapta=new CopacDreapta();

    public static final int TILE_WIDTH  = 32;                       /*!< Latimea unei dale.*/
    public static final int TILE_HEIGHT = 32;                       /*!< Inaltimea unei dale.*/

    protected BufferedImage img;                                    /*!< Imaginea aferenta tipului de dala.*/
    protected final int id;                                         /*!< Id-ul unic aferent tipului de dala.*/

    /*! \fn public Tile(BufferedImage texture, int id)
        \brief Constructorul aferent clasei.

        \param image Imaginea corespunzatoare dalei.
        \param id Id-ul dalei.
     */
    public Tile(BufferedImage image, int idd)
    {
        img = image;
        id = idd;

        tiles[id] = this;
    }

    /*! \fn public void Update()
        \brief Actualizeaza proprietatile dalei.
     */
    public void Update()
    {

    }

    /*! \fn public void Draw(Graphics g, int x, int y)
        \brief Deseneaza in fereastra dala.

        \param g Contextul grafic in care sa se realizeze desenarea
        \param x Coordonata x in cadrul ferestrei unde sa fie desenata dala
        \param y Coordonata y in cadrul ferestrei unde sa fie desenata dala
     */
    public void Draw(Graphics g, int x, int y)
    {
            /// Desenare dala
        g.drawImage(img, x, y, TILE_WIDTH, TILE_HEIGHT, null);
    }

    /*! \fn public boolean IsSolid()
        \brief Returneaza proprietatea de dala solida (supusa coliziunilor) sau nu.
     */
    public boolean IsSolid()
    {
        return false;
    }

    /*! \fn public int GetId()
        \brief Returneaza id-ul dalei.
     */
    public int GetId()
    {
        return id;
    }
}
