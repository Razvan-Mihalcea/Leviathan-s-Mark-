package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class Cruce extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Cruce() {
        super(Assets.cruce, Assets.index("cruce"));
    }
}
