package LeviathansMark.Tiles;

import LeviathansMark.Graphics.Assets;

public class Gard4 extends Tile {
    /*! \fn public TreeTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public Gard4() {
        super(Assets.gard4, Assets.index("gard4"));
    }
}
