package LeviathansMark.Graphics;

import java.awt.image.BufferedImage;

/*! \class public class Assets
    \brief Clasa incarca fiecare element grafic necesar jocului.

    Game assets include tot ce este folosit intr-un joc: imagini, sunete, harti etc.
 */
public class Assets {
    /// Referinte catre elementele grafice (dale) utilizate in joc.
    public static BufferedImage margine;
    public static BufferedImage zid;
    public static BufferedImage zidcrapat;
    public static BufferedImage blocnegru;
    public static BufferedImage zidiarba;
    public static BufferedImage podeaiarba;
    public static BufferedImage cutie;
    public static BufferedImage podea;
    public static BufferedImage zidiarba2;
    public static BufferedImage podea1;
    public static BufferedImage podea2;
    public static BufferedImage podea3;
    public static BufferedImage podea4;
    public static BufferedImage podea5;
    public static BufferedImage podea6;
    public static BufferedImage podea7;
    public static BufferedImage obiect;
    public static BufferedImage gard1;
    public static BufferedImage gard2;
    public static BufferedImage gard3;
    public static BufferedImage coffin;
    public static BufferedImage coffin2;
    public static BufferedImage podealvl2;
    public static BufferedImage gard4;
    public static BufferedImage gard5;
    public static BufferedImage podeacoffin;
    public static BufferedImage marginezid;
    public static BufferedImage marginezid2;
    public static BufferedImage lumanare;
    public static BufferedImage cruce;
    public static BufferedImage cruce2;
    public static BufferedImage copacstanga;
    public static BufferedImage copacdreapta;
    public static BufferedImage heroLeft;
    public static BufferedImage heroRight;
    public static BufferedImage heroUP;
    public static BufferedImage heroDown;
    public static SpriteSheet EnemySheet = new SpriteSheet(ImageLoader.LoadImage("/textures/Enemy.png"));
    public static SpriteSheet tileSheet = new SpriteSheet(ImageLoader.LoadImage("/textures/lvlll1.png"));
    public static SpriteSheet tileSheet2 = new SpriteSheet(ImageLoader.LoadImage("/textures/lvl2.png"));
    public static SpriteSheet heroSheet = new SpriteSheet(ImageLoader.LoadImage("/textures/Hero.png"));
    public static SpriteSheet heroAttackSheet=new SpriteSheet(ImageLoader.LoadImage("/textures/Attack.png"));
    /*! \fn public static void Init()
        \brief Functia initializaza referintele catre elementele grafice utilizate.

        Aceasta functie poate fi rescrisa astfel incat elementele grafice incarcate/utilizate
        sa fie parametrizate. Din acest motiv referintele nu sunt finale.
     */
    public static void Init(){
        /// Se creaza temporar un obiect SpriteSheet initializat prin intermediul clasei ImageLoader

         ///Se obtin subimaginile corespunzatoare elementelor necesare.
        margine = tileSheet.cropTile(0);
        zid = tileSheet.cropTile(1);
        zidcrapat = tileSheet.cropTile(2);
        blocnegru = tileSheet.cropTile(3);
        zidiarba = tileSheet.cropTile(4);
        podeaiarba = tileSheet.cropTile(5);
        cutie = tileSheet.cropTile(6);
        podea = tileSheet.cropTile(7);
        zidiarba2 = tileSheet.cropTile(8);
        podea1 = tileSheet.cropTile(9);
        podea2 = tileSheet.cropTile(10);
        podea3 = tileSheet.cropTile(11);
        podea4 = tileSheet.cropTile(12);
        podea5 = tileSheet.cropTile(13);
        podea6 = tileSheet.cropTile(14);
        podea7 = tileSheet.cropTile(15);
        obiect = tileSheet.cropTile(16);
        gard1=tileSheet2.crop(0,0);
        gard2=tileSheet2.crop(1,0);
        gard3=tileSheet2.crop(2,0);
        coffin=tileSheet2.crop(3,0);
        coffin2=tileSheet2.crop(4,0);
        podealvl2=tileSheet2.crop(5,0);
        gard4=tileSheet2.crop(6,0);
        gard5=tileSheet2.crop(7,0);
        podeacoffin=tileSheet2.crop(0,1);
        marginezid=tileSheet2.crop(1,1);
        marginezid2=tileSheet2.crop(2,1);
        lumanare=tileSheet2.crop(3,1);
        cruce=tileSheet2.crop(4,1);
        cruce2=tileSheet2.crop(5,1);
        copacstanga=tileSheet2.crop(6,1);
        copacdreapta=tileSheet2.crop(7,1);
        heroLeft = heroSheet.Character_crop(0, 1);
        heroRight = heroSheet.Character_crop(1, 0);
        heroDown = heroSheet.Character_crop(2, 0);
        heroUP = heroSheet.Character_crop(3, 0);
    }

    public static int index(String dala) {
        switch (dala) {
            case "margine":
                return 0;
            case "zid":
                return 1;
            case "zidcrapat":
                return 2;
            case "blocnegru":
                return 3;
            case "zidiarba":
                return 4;
            case "podeaiarba":
                return 5;
            case "cutie":
                return 6;
            case "podea":
                return 7;
            case "zidiarba2":
                return 8;
            case "podea1":
                return 9;
            case "podea2":
                return 10;
            case "podea3":
                return 11;
            case "podea4":
                return 12;
            case "podea5":
                return 13;
            case "podea6":
                return 14;
            case "podea7":
                return 15;
            case "obiect":
                return 16;
            case "cutie2":
                return 17;
            case "podea8":
                return 18;
            case "gard1":
                return 19;
            case "gard2":
                return 20;
            case "gard3":
                return 21;
            case "coffin":
                return 22;
            case "coffin2":
                return 23;
            case "podealvl2":
                return 24;
            case "gard4":
                return 25;
            case "gard5":
                return 26;
            case "podeacoffin":
                return 27;
            case "marginezid":
                return 28;
            case "marginezid2":
                return 29;
            case "lumanare":
                return 30;
            case "cruce":
                return 31;
            case "cruce2":
                return 32;
            case "copacstanga":
                return 33;
            case "copacdreapta":
                return 34;
            default:
                return 34;
        }
    }
}
