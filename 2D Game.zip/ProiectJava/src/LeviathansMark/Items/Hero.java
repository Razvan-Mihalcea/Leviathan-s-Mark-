package LeviathansMark.Items;

import java.awt.*;
import java.awt.image.BufferedImage;

import LeviathansMark.Graphics.Animation;
import LeviathansMark.RefLinks;
import LeviathansMark.Graphics.Assets;

/*! \class public class Hero extends Character
    \brief Implementeaza notiunea de erou/player (caracterul controlat de jucator).

    Elementele suplimentare pe care le aduce fata de clasa de baza sunt:
        imaginea (acest atribut poate fi ridicat si in clasa de baza)
        deplasarea
        atacul (nu este implementat momentan)
        dreptunghiul de coliziune
 */
public class Hero extends Character
{
    
    private BufferedImage image;/*!< Referinta catre imaginea curenta a eroului.*/
    private BufferedImage[] walkleft={Assets.heroSheet.Character_crop(0,1),Assets.heroSheet.Character_crop(1,1),Assets.heroSheet.Character_crop(2,1),Assets.heroSheet.Character_crop(3,1),Assets.heroSheet.Character_crop(4,1),Assets.heroSheet.Character_crop(5,1),Assets.heroSheet.Character_crop(6,1),Assets.heroSheet.Character_crop(7,1)};
    private final BufferedImage[] walkright={Assets.heroSheet.Character_crop(0,0),Assets.heroSheet.Character_crop(1,0),Assets.heroSheet.Character_crop(2,0),Assets.heroSheet.Character_crop(3,0),Assets.heroSheet.Character_crop(4,0),Assets.heroSheet.Character_crop(5,0),Assets.heroSheet.Character_crop(6,0),Assets.heroSheet.Character_crop(7,0)};
    private BufferedImage[] walkdown={Assets.heroSheet.Character_crop(0,2),Assets.heroSheet.Character_crop(1,2),Assets.heroSheet.Character_crop(2,2),Assets.heroSheet.Character_crop(3,2),Assets.heroSheet.Character_crop(4,2),Assets.heroSheet.Character_crop(5,2),Assets.heroSheet.Character_crop(6,2),Assets.heroSheet.Character_crop(7,2)};
    private BufferedImage[] walkup={Assets.heroSheet.Character_crop(0,3),Assets.heroSheet.Character_crop(1,3),Assets.heroSheet.Character_crop(2,3),Assets.heroSheet.Character_crop(3,3),Assets.heroSheet.Character_crop(4,3),Assets.heroSheet.Character_crop(5,3),Assets.heroSheet.Character_crop(6,3),Assets.heroSheet.Character_crop(7,3)};

    private BufferedImage[] attackRight ={Assets.heroAttackSheet.Character_crop(0,0),Assets.heroAttackSheet.Character_crop(1,0),Assets.heroAttackSheet.Character_crop(2,0)};
    private BufferedImage[] attackLeft = {Assets.heroAttackSheet.Character_crop(0,1),Assets.heroAttackSheet.Character_crop(1,1),Assets.heroAttackSheet.Character_crop(2,1)};

    private Animation walkLeft=new Animation(walkleft,12);
    private Animation walkRight=new Animation(walkright,12);
    private Animation walkUp=new Animation(walkup,12);
    private Animation walkDown=new Animation(walkdown,12);
    private Animation AttackLeft=new Animation(attackLeft,12);
    private Animation AttackRight=new Animation(attackRight,12);
    private Animation animation;
    public static int Punctaj;

    /*! \fn public Hero(RefLinks refLink, float x, float y)
        \brief Constructorul de initializare al clasei Hero.

        \param refLink Referinta catre obiectul shortcut (obiect ce retine o serie de referinte din program).
        \param x Pozitia initiala pe axa X a eroului.
        \param y Pozitia initiala pe axa Y a eroului.
     */
    public Hero(RefLinks refLink, float x, float y)
    {
            ///Apel al constructorului clasei de baza
        super(refLink, x,y, Character.DEFAULT_CREATURE_WIDTH, Character.DEFAULT_CREATURE_HEIGHT);

            ///Seteaza imaginea de start a eroului
        image = Assets.heroDown;
            ///Stabilieste pozitia relativa si dimensiunea dreptunghiului de coliziune, starea implicita(normala)
        normalBounds.x = 0;
        normalBounds.y = 0;
        normalBounds.width = 28;
        normalBounds.height = 28;

            ///Stabilieste pozitia relativa si dimensiunea dreptunghiului de coliziune, starea de atac
        attackBounds.x = 0;
        attackBounds.y = 0;
        attackBounds.width = 32;
        attackBounds.height = 32;
        animation = walkLeft;
        animation.start();
    }

    /*! \fn public void Update()
        \brief Actualizeaza pozitia si imaginea eroului.
     */
    @Override
    public void Update() {
        if (life > 0) {
            ///Verifica daca a fost apasata o tasta
            GetInput();
            ///Actualizeaza pozitia
            Move();
            ///Actualizeaza imaginea
            if (refLink.GetKeyManager().attack == true) {
                if (animation == walkLeft)
                    animation = AttackLeft;
                if (animation == walkRight)
                    animation = AttackRight;
                animation.start();
            }
            if (refLink.GetKeyManager().left == true) {
                animation = walkLeft;
                animation.start();
            }
            if (refLink.GetKeyManager().right == true) {
                animation = walkRight;
                animation.start();
            }
            if (refLink.GetKeyManager().down == true) {
                animation = walkDown;
                animation.start();
            }
            if (refLink.GetKeyManager().up == true) {
                animation = walkUp;
                animation.start();
            }
            if (animation == AttackLeft && animation.stopped)
                animation = walkLeft;
            if (animation == AttackRight && animation.stopped)
                animation = walkRight;
            animation.update();
            //System.out.println(x+" "+y+" "+x/16+" "+y / 16);
        }
    }

    /*! \fn private void GetInput()
        \brief Verifica daca a fost apasata o tasta din cele stabilite pentru controlul eroului.
     */
    private void GetInput()
    {
            ///Implicit eroul nu trebuie sa se deplaseze daca nu este apasata o tasta
        this.xMove = 0;
        this.yMove = 0;
            ///Verificare apasare tasta "sus"
        if(refLink.GetKeyManager().up)
        {
            yMove = -speed;
            animation=walkUp;
            animation.start();
        }
            ///Verificare apasare tasta "jos"
        if(refLink.GetKeyManager().down)
        {
            yMove =speed;
            animation=walkDown;
            animation.start();
        }
            ///Verificare apasare tasta "left"
        if(refLink.GetKeyManager().left)
        {
            xMove = -speed;
            animation=walkLeft;
            animation.start();
        }
            ///Verificare apasare tasta "dreapta"
        if(refLink.GetKeyManager().right)
        {
            xMove = speed;
            animation=walkRight;
            animation.start();
        }

    }
    public void Punctajinc(int amt)
    {
        Punctaj+=amt;
    }
    public int GetPunctaj()
    {
        return Punctaj;
    }
    public void die()
    {
        if(life==0)
            System.out.println("Ai pierdut");
    }
    @Override
    public boolean Exist(float x,float y)
    {
        return false;
    }

    /*! \fn public void Draw(Graphics g)
        \brief Randeaza/deseneaza eroul in noua pozitie.

        \brief g Contextul grafi in care trebuie efectuata desenarea eroului.
     */
    @Override
    public void Draw(Graphics g)
    {
        g.drawImage(this.animation.getSprite(), (int)x, (int)y, DEFAULT_CREATURE_WIDTH, DEFAULT_CREATURE_HEIGHT, null);

            ///doar pentru debug daca se doreste vizualizarea dreptunghiului de coliziune altfel se vor comenta urmatoarele doua linii
        //g.setColor(Color.blue);
        //g.fillRect((int)(x ), (int)(y ), 16, 16);
    }
    public boolean GetAttack(){
        if(refLink.GetKeyManager().attack==true)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public void setYMove(float v)
    {
        yMove=v;
    }
    public void setXMove(float v)
    {
        xMove=v;
    }
}
