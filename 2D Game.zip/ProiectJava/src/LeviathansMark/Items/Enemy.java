package LeviathansMark.Items;

import LeviathansMark.Graphics.Animation;
import LeviathansMark.Graphics.Assets;
import LeviathansMark.RefLinks;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Enemy extends Character
{
    private BufferedImage[] idleright=new BufferedImage[]{(Assets.EnemySheet.cropEnemy(0)),(Assets.EnemySheet.cropEnemy(1)),(Assets.EnemySheet.cropEnemy(2)),(Assets.EnemySheet.cropEnemy(3))};
    private Animation idle;
    private Animation animation;
    public Enemy(RefLinks refLink, float x, float y, int width, int height) {
        super(refLink, x, y, width, height);
        this.idle=new Animation(this.idleright,8);
        this.animation=this.idle;
        animation.start();
        ///Stabilieste pozitia relativa si dimensiunea dreptunghiului de coliziune, starea implicita(normala)
        normalBounds.x = 0;
        normalBounds.y = 0;
        normalBounds.width = 28;
        normalBounds.height = 28;

        ///Stabilieste pozitia relativa si dimensiunea dreptunghiului de coliziune, starea de atac
        attackBounds.x = 0;
        attackBounds.y = 0;
        attackBounds.width = 32;
        attackBounds.height = 32;
    }

    @Override
    public void die() {

    }

    @Override
    public void Update()
    {
        if(animation.stopped)
        {
            animation.start();
        }
        this.animation.update();
    }

    @Override
    public void Draw(Graphics g)
    {
        g.drawImage(animation.getSprite(), (int)x, (int)y, DEFAULT_CREATURE_WIDTH, DEFAULT_CREATURE_HEIGHT, null);
    }
    @Override
    public Rectangle getBounds()
    {
        return normalBounds;
    }

//    @Override
    public boolean Exist(float x,float y)
    {
        if(this.x<x&&this.x+this.width>x&&this.y<y&&this.y+this.height>y) {
            return true;
        }
        else{
            return false;
        }
    }
}
